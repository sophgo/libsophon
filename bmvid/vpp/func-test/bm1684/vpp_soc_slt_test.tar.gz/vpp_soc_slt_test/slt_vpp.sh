#!/bin/bash
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/system/lib:/system/usr/lib/aarch64-linux-gnu
PATH=$PATH:$HOME/bin:/system/bin

date
if [ $# -ge 1 ];then
  test_loop=$1
else
  test_loop=1
fi
echo "test_loop=$test_loop"

echo "test start"
start_time=`date +%s`

pushd /root/SLT/vpp/
for loop in $(seq 1 $test_loop)
do
  echo "vpp test $loop started"
  fbcmulti 1 10 5000 500 >vpp.log 2>&1
  if [ $? -ne 0 ]; then
    echo "1684SLT VPP FAIL"
    echo "1684SLT VPP FAIL"
    echo "1684SLT VPP FAIL"
	popd
    exit 1
  fi
  echo "vpp test $loop passed"
done

end_time=`date +%s`
test_time=$((end_time-start_time))
echo "test time $test_time"

date
echo "1684SLT VPP PASS"
echo "1684SLT VPP PASS"
echo "1684SLT VPP PASS"

popd
